
let circle = d3.select("#viz").selectAll("circle");
circle.style("fill", "steelblue");
circle.attr("r", 30);